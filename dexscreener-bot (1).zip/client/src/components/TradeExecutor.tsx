import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { AlertCircle, CheckCircle, Loader2, Send } from 'lucide-react';
import { useWeb3 } from '@/contexts/Web3Context';
import { toast } from 'sonner';

interface TradeExecutorProps {
  tokenSymbol: string;
  tokenAddress: string;
  currentPrice: number;
  chainId: string;
}

export const TradeExecutor: React.FC<TradeExecutorProps> = ({
  tokenSymbol,
  tokenAddress,
  currentPrice,
  chainId,
}) => {
  const { account, isConnected, executeSwap } = useWeb3();
  const [amount, setAmount] = useState('');
  const [slippage, setSlippage] = useState('0.5');
  const [isExecuting, setIsExecuting] = useState(false);
  const [txHash, setTxHash] = useState<string | null>(null);

  const handleExecuteTrade = async () => {
    if (!isConnected || !account) {
      toast.error('Please connect your MetaMask wallet first');
      return;
    }

    if (!amount || parseFloat(amount) <= 0) {
      toast.error('Please enter a valid amount');
      return;
    }

    try {
      setIsExecuting(true);
      const slippagePercent = parseFloat(slippage) / 100;
      const minAmountOut = (parseFloat(amount) * (1 - slippagePercent)).toString();

      const hash = await executeSwap(
        '0x0000000000000000000000000000000000000000', // ETH
        tokenAddress,
        amount,
        minAmountOut
      );

      setTxHash(hash);
      setAmount('');
      toast.success(`Trade executed! TX: ${hash.slice(0, 10)}...`);
    } catch (error) {
      console.error('Trade execution failed:', error);
      toast.error('Trade execution failed. Please try again.');
    } finally {
      setIsExecuting(false);
    }
  };

  if (!isConnected) {
    return (
      <Card className="border-warning/20">
        <CardContent className="pt-6">
          <div className="flex items-center gap-3 text-warning">
            <AlertCircle className="h-5 w-5" />
            <p>Connect your MetaMask wallet to execute trades</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-primary/20 glow-primary">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>Execute Trade</span>
          <Badge variant="outline">{tokenSymbol}</Badge>
        </CardTitle>
        <CardDescription>
          Buy {tokenSymbol} at ${currentPrice.toFixed(6)}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {txHash && (
          <div className="bg-accent/10 border border-accent rounded-lg p-4 flex items-start gap-3">
            <CheckCircle className="h-5 w-5 text-accent mt-0.5 flex-shrink-0" />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-accent mb-1">Trade Executed Successfully</p>
              <code className="text-xs bg-background/50 px-2 py-1 rounded break-all">
                {txHash}
              </code>
            </div>
          </div>
        )}

        <div className="space-y-2">
          <label className="text-sm font-medium">Amount (ETH)</label>
          <Input
            type="number"
            placeholder="0.1"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            disabled={isExecuting}
            step="0.001"
            min="0"
          />
          <p className="text-xs text-muted-foreground">
            Estimated {tokenSymbol}: {amount ? (parseFloat(amount) / currentPrice).toFixed(4) : '0'}
          </p>
        </div>

        <div className="space-y-2">
          <label className="text-sm font-medium">Slippage Tolerance (%)</label>
          <div className="flex gap-2">
            {['0.1', '0.5', '1', '2'].map((value) => (
              <Button
                key={value}
                variant={slippage === value ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSlippage(value)}
                disabled={isExecuting}
              >
                {value}%
              </Button>
            ))}
            <Input
              type="number"
              placeholder="Custom"
              value={slippage}
              onChange={(e) => setSlippage(e.target.value)}
              disabled={isExecuting}
              className="w-20"
              step="0.1"
              min="0"
            />
          </div>
        </div>

        <div className="bg-background/50 rounded-lg p-3 space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-muted-foreground">Price Impact</span>
            <span className="text-warning">~{slippage}%</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Min Received</span>
            <span className="font-semibold">
              {amount ? (parseFloat(amount) / currentPrice * (1 - parseFloat(slippage) / 100)).toFixed(4) : '0'} {tokenSymbol}
            </span>
          </div>
        </div>

        <Button
          onClick={handleExecuteTrade}
          disabled={isExecuting || !amount || parseFloat(amount) <= 0}
          className="w-full"
          size="lg"
        >
          {isExecuting ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Executing...
            </>
          ) : (
            <>
              <Send className="mr-2 h-4 w-4" />
              Execute Trade
            </>
          )}
        </Button>

        <p className="text-xs text-muted-foreground text-center">
          Make sure to review the transaction details in MetaMask before confirming
        </p>
      </CardContent>
    </Card>
  );
};
