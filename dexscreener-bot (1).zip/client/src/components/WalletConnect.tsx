import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Wallet, LogOut, Loader2 } from 'lucide-react';
import { useWeb3 } from '@/contexts/Web3Context';

export const WalletConnect: React.FC = () => {
  const { account, isConnected, isConnecting, balance, chainId, connectWallet, disconnectWallet, switchNetwork } = useWeb3();

  const getChainName = (id: number | null) => {
    const chains: { [key: number]: string } = {
      1: 'Ethereum',
      137: 'Polygon',
      56: 'BSC',
      43114: 'Avalanche',
      42161: 'Arbitrum',
    };
    return chains[id || 1] || 'Unknown';
  };

  const formatAddress = (addr: string) => {
    return `${addr.slice(0, 6)}...${addr.slice(-4)}`;
  };

  if (isConnected && account) {
    return (
      <Card className="border-primary/20 glow-primary">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Wallet className="h-5 w-5 text-primary" />
            Connected Wallet
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <div className="text-sm text-muted-foreground">Account</div>
            <div className="flex items-center justify-between">
              <code className="text-sm font-mono bg-background/50 px-3 py-2 rounded border border-border">
                {formatAddress(account)}
              </code>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigator.clipboard.writeText(account)}
              >
                Copy
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <div className="text-sm text-muted-foreground mb-1">Network</div>
              <Badge variant="outline">{getChainName(chainId)}</Badge>
            </div>
            <div>
              <div className="text-sm text-muted-foreground mb-1">Balance</div>
              <div className="font-semibold">{balance ? parseFloat(balance).toFixed(4) : '0'} ETH</div>
            </div>
          </div>

          <div className="space-y-2">
            <div className="text-sm text-muted-foreground">Switch Network</div>
            <div className="grid grid-cols-2 gap-2">
              <Button
                variant={chainId === 1 ? 'default' : 'outline'}
                size="sm"
                onClick={() => switchNetwork(1)}
              >
                Ethereum
              </Button>
              <Button
                variant={chainId === 137 ? 'default' : 'outline'}
                size="sm"
                onClick={() => switchNetwork(137)}
              >
                Polygon
              </Button>
            </div>
          </div>

          <Button
            variant="destructive"
            className="w-full"
            onClick={disconnectWallet}
          >
            <LogOut className="mr-2 h-4 w-4" />
            Disconnect Wallet
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-primary/20">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Wallet className="h-5 w-5" />
          Connect Wallet
        </CardTitle>
        <CardDescription>
          Connect your MetaMask wallet to execute trades automatically
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Button
          onClick={connectWallet}
          disabled={isConnecting}
          className="w-full"
          size="lg"
        >
          {isConnecting ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Connecting...
            </>
          ) : (
            <>
              <Wallet className="mr-2 h-4 w-4" />
              Connect MetaMask
            </>
          )}
        </Button>
        <p className="text-xs text-muted-foreground mt-4 text-center">
          Make sure you have MetaMask installed and have selected Ethereum or Polygon network
        </p>
      </CardContent>
    </Card>
  );
};
