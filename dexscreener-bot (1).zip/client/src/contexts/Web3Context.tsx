import React, { createContext, useContext, useEffect, useState } from 'react';
import { BrowserProvider, Contract, parseUnits } from 'ethers';

interface Web3ContextType {
  account: string | null;
  provider: BrowserProvider | null;
  isConnected: boolean;
  isConnecting: boolean;
  chainId: number | null;
  balance: string | null;
  connectWallet: () => Promise<void>;
  disconnectWallet: () => void;
  switchNetwork: (chainId: number) => Promise<void>;
  executeSwap: (tokenIn: string, tokenOut: string, amountIn: string, minAmountOut: string) => Promise<string>;
}

const Web3Context = createContext<Web3ContextType | undefined>(undefined);

export const Web3Provider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [account, setAccount] = useState<string | null>(null);
  const [provider, setProvider] = useState<BrowserProvider | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [chainId, setChainId] = useState<number | null>(null);
  const [balance, setBalance] = useState<string | null>(null);

  // Check if MetaMask is installed
  const hasMetaMask = () => {
    return typeof window !== 'undefined' && typeof (window as any).ethereum !== 'undefined';
  };

  // Connect wallet
  const connectWallet = async () => {
    if (!hasMetaMask()) {
      alert('Please install MetaMask to use this feature');
      return;
    }

    try {
      setIsConnecting(true);
      const ethereum = (window as any).ethereum;
      
      // Request account access
      const accounts = await ethereum.request({ method: 'eth_requestAccounts' });
      const userAccount = accounts[0];
      setAccount(userAccount);

      // Create provider
      const ethersProvider = new BrowserProvider(ethereum);
      setProvider(ethersProvider);
      setIsConnected(true);

      // Get chain ID
      const network = await ethersProvider.getNetwork();
      setChainId(Number(network.chainId));

      // Get balance
      const balance = await ethersProvider.getBalance(userAccount);
      setBalance((balance / BigInt(10 ** 18)).toString());

      // Listen for account changes
      ethereum.on('accountsChanged', (accounts: string[]) => {
        if (accounts.length === 0) {
          disconnectWallet();
        } else {
          setAccount(accounts[0]);
        }
      });

      // Listen for chain changes
      ethereum.on('chainChanged', (chainId: string) => {
        setChainId(parseInt(chainId, 16));
      });
    } catch (error) {
      console.error('Failed to connect wallet:', error);
      alert('Failed to connect wallet');
    } finally {
      setIsConnecting(false);
    }
  };

  // Disconnect wallet
  const disconnectWallet = () => {
    setAccount(null);
    setProvider(null);
    setIsConnected(false);
    setChainId(null);
    setBalance(null);
  };

  // Switch network
  const switchNetwork = async (targetChainId: number) => {
    if (!hasMetaMask()) return;

    try {
      const ethereum = (window as any).ethereum;
      const chainIdHex = `0x${targetChainId.toString(16)}`;

      try {
        await ethereum.request({
          method: 'wallet_switchEthereumChain',
          params: [{ chainId: chainIdHex }],
        });
      } catch (error: any) {
        // Chain not added, try to add it
        if (error.code === 4902) {
          const chainConfig = getChainConfig(targetChainId);
          if (chainConfig) {
            await ethereum.request({
              method: 'wallet_addEthereumChain',
              params: [chainConfig],
            });
          }
        }
      }
    } catch (error) {
      console.error('Failed to switch network:', error);
    }
  };

  // Execute swap via DEX router
  const executeSwap = async (
    tokenIn: string,
    tokenOut: string,
    amountIn: string,
    minAmountOut: string
  ): Promise<string> => {
    if (!provider || !account) {
      throw new Error('Wallet not connected');
    }

    try {
      const signer = await provider.getSigner();
      
      // Get router address based on chain
      const routerAddress = getRouterAddress(chainId || 1);
      
      // Create router contract instance
      const routerABI = getRouterABI(chainId || 1);
      const router = new Contract(routerAddress, routerABI, signer);

      // Execute swap
      let tx;
      if (tokenIn === '0x0000000000000000000000000000000000000000') {
        // Native token swap (ETH)
        tx = await router.swapExactETHForTokens(
          minAmountOut,
          [tokenIn, tokenOut],
          account,
          Math.floor(Date.now() / 1000) + 60 * 20, // 20 minutes deadline
          { value: parseUnits(amountIn, 18) }
        );
      } else if (tokenOut === '0x0000000000000000000000000000000000000000') {
        // Swap to native token
        tx = await router.swapExactTokensForETH(
          parseUnits(amountIn, 18),
          minAmountOut,
          [tokenIn, tokenOut],
          account,
          Math.floor(Date.now() / 1000) + 60 * 20
        );
      } else {
        // Token to token swap
        tx = await router.swapExactTokensForTokens(
          parseUnits(amountIn, 18),
          minAmountOut,
          [tokenIn, tokenOut],
          account,
          Math.floor(Date.now() / 1000) + 60 * 20
        );
      }

      // Wait for transaction confirmation
      const receipt = await tx.wait();
      return receipt.hash;
    } catch (error) {
      console.error('Swap execution failed:', error);
      throw error;
    }
  };

  // Check if wallet was previously connected
  useEffect(() => {
    if (hasMetaMask()) {
      const ethereum = (window as any).ethereum;
      ethereum.request({ method: 'eth_accounts' }).then((accounts: string[]) => {
        if (accounts.length > 0) {
          connectWallet();
        }
      });
    }
  }, []);

  const value: Web3ContextType = {
    account,
    provider,
    isConnected,
    isConnecting,
    chainId,
    balance,
    connectWallet,
    disconnectWallet,
    switchNetwork,
    executeSwap,
  };

  return <Web3Context.Provider value={value}>{children}</Web3Context.Provider>;
};

export const useWeb3 = () => {
  const context = useContext(Web3Context);
  if (!context) {
    throw new Error('useWeb3 must be used within Web3Provider');
  }
  return context;
};

// Helper functions
function getChainConfig(chainId: number) {
  const configs: { [key: number]: any } = {
    137: {
      chainId: '0x89',
      chainName: 'Polygon',
      nativeCurrency: { name: 'MATIC', symbol: 'MATIC', decimals: 18 },
      rpcUrls: ['https://polygon-rpc.com'],
      blockExplorerUrls: ['https://polygonscan.com'],
    },
    1: {
      chainId: '0x1',
      chainName: 'Ethereum Mainnet',
      nativeCurrency: { name: 'Ether', symbol: 'ETH', decimals: 18 },
      rpcUrls: ['https://eth-mainnet.g.alchemy.com/v2/demo'],
      blockExplorerUrls: ['https://etherscan.io'],
    },
  };
  return configs[chainId];
}

function getRouterAddress(chainId: number): string {
  // Uniswap V3 Router addresses
  const routers: { [key: number]: string } = {
    1: '0xE592427A0AEce92De3Edee1F18E0157C05861564', // Ethereum
    137: '0xE592427A0AEce92De3Edee1F18E0157C05861564', // Polygon
  };
  return routers[chainId] || routers[1];
}

function getRouterABI(chainId: number): any[] {
  // Simplified Uniswap V3 Router ABI
  return [
    {
      inputs: [
        { name: 'amountOut', type: 'uint256' },
        { name: 'path', type: 'address[]' },
        { name: 'to', type: 'address' },
        { name: 'deadline', type: 'uint256' },
      ],
      name: 'swapExactETHForTokens',
      outputs: [{ name: 'amounts', type: 'uint256[]' }],
      stateMutability: 'payable',
      type: 'function',
    },
    {
      inputs: [
        { name: 'amountIn', type: 'uint256' },
        { name: 'amountOutMin', type: 'uint256' },
        { name: 'path', type: 'address[]' },
        { name: 'to', type: 'address' },
        { name: 'deadline', type: 'uint256' },
      ],
      name: 'swapExactTokensForETH',
      outputs: [{ name: 'amounts', type: 'uint256[]' }],
      stateMutability: 'nonpayable',
      type: 'function',
    },
    {
      inputs: [
        { name: 'amountIn', type: 'uint256' },
        { name: 'amountOutMin', type: 'uint256' },
        { name: 'path', type: 'address[]' },
        { name: 'to', type: 'address' },
        { name: 'deadline', type: 'uint256' },
      ],
      name: 'swapExactTokensForTokens',
      outputs: [{ name: 'amounts', type: 'uint256[]' }],
      stateMutability: 'nonpayable',
      type: 'function',
    },
  ];
}
