import { useState, useEffect } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { 
  Play, 
  Square, 
  Plus, 
  Trash2, 
  Activity, 
  TrendingUp, 
  TrendingDown, 
  Bell, 
  Settings,
  Loader2,
  ArrowLeft,
  DollarSign,
  Clock,
  Target
} from "lucide-react";
import { trpc } from "@/lib/trpc";
import { Link } from "wouter";
import { toast } from "sonner";
import { getLoginUrl } from "@/const";
import { WalletConnect } from "@/components/WalletConnect";
import { TradeExecutor } from "@/components/TradeExecutor";

export default function Bot() {
  const { user, isAuthenticated, loading } = useAuth();
  const [addTokenOpen, setAddTokenOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  
  // Bot queries
  const { data: config, refetch: refetchConfig } = trpc.bot.getConfig.useQuery(undefined, {
    enabled: isAuthenticated,
  });
  
  const { data: status, refetch: refetchStatus } = trpc.bot.getStatus.useQuery(undefined, {
    enabled: isAuthenticated,
    refetchInterval: 5000, // Refresh every 5 seconds
  });
  
  const { data: tokens, refetch: refetchTokens } = trpc.bot.getTokens.useQuery(undefined, {
    enabled: isAuthenticated,
  });
  
  const { data: activeTrades, refetch: refetchActiveTrades } = trpc.bot.getActiveTrades.useQuery(undefined, {
    enabled: isAuthenticated,
    refetchInterval: 10000, // Refresh every 10 seconds
  });
  
  const { data: tradeHistory } = trpc.bot.getTradeHistory.useQuery({ limit: 20 }, {
    enabled: isAuthenticated,
  });
  
  const { data: alerts, refetch: refetchAlerts } = trpc.bot.getAlerts.useQuery({ unreadOnly: false }, {
    enabled: isAuthenticated,
    refetchInterval: 5000, // Refresh every 5 seconds
  });
  
  const { data: stats } = trpc.bot.getStats.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  // Mutations
  const startBot = trpc.bot.start.useMutation({
    onSuccess: () => {
      toast.success("Bot started successfully!");
      refetchConfig();
      refetchStatus();
    },
    onError: (error) => {
      toast.error(`Failed to start bot: ${error.message}`);
    },
  });

  const stopBot = trpc.bot.stop.useMutation({
    onSuccess: () => {
      toast.success("Bot stopped");
      refetchConfig();
      refetchStatus();
    },
    onError: (error) => {
      toast.error(`Failed to stop bot: ${error.message}`);
    },
  });

  const addToken = trpc.bot.addToken.useMutation({
    onSuccess: () => {
      toast.success("Token added to watchlist");
      refetchTokens();
      setAddTokenOpen(false);
      setSearchQuery("");
    },
    onError: (error) => {
      toast.error(`Failed to add token: ${error.message}`);
    },
  });

  const removeToken = trpc.bot.removeToken.useMutation({
    onSuccess: () => {
      toast.success("Token removed from watchlist");
      refetchTokens();
    },
    onError: (error) => {
      toast.error(`Failed to remove token: ${error.message}`);
    },
  });

  // Search for token to add
  const { data: searchResults, isLoading: isSearching } = trpc.dexscreener.search.useQuery(
    { query: searchQuery },
    { enabled: searchQuery.length > 0 }
  );

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle>Authentication Required</CardTitle>
            <CardDescription>Please sign in to access the trading bot</CardDescription>
          </CardHeader>
          <CardContent>
            <Button onClick={() => window.location.href = getLoginUrl()} className="w-full">
              Sign In
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const handleAddTokenFromSearch = (pair: any) => {
    addToken.mutate({
      chainId: pair.chainId,
      tokenAddress: pair.baseToken.address,
      tokenSymbol: pair.baseToken.symbol,
      tokenName: pair.baseToken.name,
      pairAddress: pair.pairAddress,
      minLiquidity: 10000,
    });
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link href="/">
                <Button variant="ghost" size="icon">
                  <ArrowLeft className="h-5 w-5" />
                </Button>
              </Link>
              <div className="flex items-center gap-2">
                <Activity className="h-6 w-6 text-primary" />
                <span className="text-lg font-bold">Trading Bot</span>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant={status?.isRunning ? "default" : "secondary"}>
                {status?.isRunning ? "Running" : "Stopped"}
              </Badge>
            </div>
          </div>
        </div>
      </header>

      <div className="container py-8 space-y-8">
        {/* Wallet Connection Section */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-1">
            <WalletConnect />
          </div>
          <div className="lg:col-span-2">
            <TradeExecutor
              tokenSymbol="SOL"
              tokenAddress="0x0000000000000000000000000000000000000000"
              currentPrice={156.09}
              chainId="solana"
            />
          </div>
        </div>
        {/* Bot Controls */}
        <Card className="mb-8 border-primary/20">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Bot Controls</CardTitle>
                <CardDescription>Start or stop the automated trading bot</CardDescription>
              </div>
              <div className="flex gap-2">
                {status?.isRunning ? (
                  <Button
                    onClick={() => stopBot.mutate()}
                    disabled={stopBot.isPending}
                    variant="destructive"
                  >
                    <Square className="mr-2 h-4 w-4" />
                    Stop Bot
                  </Button>
                ) : (
                  <Button
                    onClick={() => startBot.mutate()}
                    disabled={startBot.isPending || !tokens || tokens.length === 0}
                    className="glow-primary"
                  >
                    <Play className="mr-2 h-4 w-4" />
                    Start Bot
                  </Button>
                )}
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <DollarSign className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <div className="text-xs text-muted-foreground">Virtual Capital</div>
                  <div className="font-semibold">${config?.virtualCapital || 0}</div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-accent/10 flex items-center justify-center">
                  <Target className="h-5 w-5 text-accent" />
                </div>
                <div>
                  <div className="text-xs text-muted-foreground">Position Size</div>
                  <div className="font-semibold">{config?.positionSize || 0}%</div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Clock className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <div className="text-xs text-muted-foreground">Check Interval</div>
                  <div className="font-semibold">{config?.checkInterval ? `${config.checkInterval}s` : "N/A"}</div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-accent/10 flex items-center justify-center">
                  <Activity className="h-5 w-5 text-accent" />
                </div>
                <div>
                  <div className="text-xs text-muted-foreground">Active Trades</div>
                  <div className="font-semibold">{status?.activeTradesCount || 0}</div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Statistics */}
        {stats && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            <Card>
              <CardContent className="p-4">
                <div className="text-sm text-muted-foreground mb-1">Total Trades</div>
                <div className="text-2xl font-bold">{stats.totalTrades}</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="text-sm text-muted-foreground mb-1">Win Rate</div>
                <div className="text-2xl font-bold text-accent">{stats.winRate}%</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="text-sm text-muted-foreground mb-1">Total P/L</div>
                <div className={`text-2xl font-bold ${parseFloat(stats.totalProfitLoss) >= 0 ? "text-accent" : "text-destructive"}`}>
                  ${stats.totalProfitLoss}
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="text-sm text-muted-foreground mb-1">Open Trades</div>
                <div className="text-2xl font-bold">{stats.openTrades}</div>
              </CardContent>
            </Card>
          </div>
        )}

        <Tabs defaultValue="tokens" className="space-y-6">
          <TabsList className="grid w-full md:w-[600px] grid-cols-4">
            <TabsTrigger value="tokens">Tokens ({tokens?.length || 0})</TabsTrigger>
            <TabsTrigger value="active">Active ({activeTrades?.length || 0})</TabsTrigger>
            <TabsTrigger value="history">History</TabsTrigger>
            <TabsTrigger value="alerts">
              Alerts
              {alerts && alerts.filter(a => a.isRead === 0).length > 0 && (
                <Badge className="ml-2" variant="destructive">
                  {alerts.filter(a => a.isRead === 0).length}
                </Badge>
              )}
            </TabsTrigger>
          </TabsList>

          {/* Monitored Tokens Tab */}
          <TabsContent value="tokens" className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-semibold">Monitored Tokens</h3>
              <Dialog open={addTokenOpen} onOpenChange={setAddTokenOpen}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="mr-2 h-4 w-4" />
                    Add Token
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Add Token to Watchlist</DialogTitle>
                    <DialogDescription>
                      Search for a token to add to your bot's monitoring list
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label>Search Token</Label>
                      <Input
                        placeholder="Enter token name or symbol..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                      />
                    </div>
                    {isSearching && (
                      <div className="flex justify-center py-8">
                        <Loader2 className="h-6 w-6 animate-spin text-primary" />
                      </div>
                    )}
                    {searchResults && searchResults.length > 0 && (
                      <div className="space-y-2">
                        {searchResults.slice(0, 10).map((pair, index) => (
                          <Card key={index} className="cursor-pointer hover:border-primary/50 transition-all">
                            <CardContent className="p-4">
                              <div className="flex items-center justify-between">
                                <div>
                                  <div className="font-semibold">
                                    {pair.baseToken.symbol} / {pair.quoteToken.symbol}
                                  </div>
                                  <div className="text-sm text-muted-foreground">
                                    {pair.chainId} • {pair.dexId}
                                  </div>
                                </div>
                                <Button
                                  size="sm"
                                  onClick={() => handleAddTokenFromSearch(pair)}
                                  disabled={addToken.isPending}
                                >
                                  Add
                                </Button>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    )}
                  </div>
                </DialogContent>
              </Dialog>
            </div>

            {tokens && tokens.length > 0 ? (
              <div className="grid gap-4">
                {tokens.map((token) => (
                  <Card key={token.id}>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="font-semibold text-lg">{token.tokenSymbol}</div>
                          <div className="text-sm text-muted-foreground">{token.tokenName}</div>
                          <div className="flex gap-2 mt-2">
                            <Badge variant="outline">{token.chainId}</Badge>
                            <Badge variant="outline">Min Liq: ${token.minLiquidity}</Badge>
                          </div>
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => removeToken.mutate({ tokenId: token.id })}
                          disabled={removeToken.isPending}
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="py-12 text-center text-muted-foreground">
                  <Activity className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>No tokens added yet. Add tokens to start monitoring.</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Active Trades Tab */}
          <TabsContent value="active" className="space-y-4">
            <h3 className="text-lg font-semibold">Active Trades</h3>
            {activeTrades && activeTrades.length > 0 ? (
              <div className="space-y-4">
                {activeTrades.map((trade) => {
                  const entryPrice = parseFloat(trade.entryPrice);
                  const timeElapsed = Date.now() - new Date(trade.entryTime).getTime();
                  const minutesElapsed = Math.floor(timeElapsed / (1000 * 60));
                  
                  return (
                    <Card key={trade.id} className="border-primary/20">
                      <CardContent className="p-6">
                        <div className="flex items-center justify-between mb-4">
                          <div>
                            <h4 className="text-xl font-bold">{trade.tokenSymbol}</h4>
                            <Badge variant="outline">{trade.chainId}</Badge>
                          </div>
                          <Badge className="bg-accent">OPEN</Badge>
                        </div>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                          <div>
                            <div className="text-xs text-muted-foreground mb-1">Entry Price</div>
                            <div className="font-semibold">${entryPrice.toFixed(6)}</div>
                          </div>
                          <div>
                            <div className="text-xs text-muted-foreground mb-1">Position Size</div>
                            <div className="font-semibold">${trade.positionSizeUsd}</div>
                          </div>
                          <div>
                            <div className="text-xs text-muted-foreground mb-1">Time Elapsed</div>
                            <div className="font-semibold">{minutesElapsed}m</div>
                          </div>
                          <div>
                            <div className="text-xs text-muted-foreground mb-1">Entry Signal</div>
                            <div className="font-semibold text-accent">+{trade.entryPriceChange5m}%</div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            ) : (
              <Card>
                <CardContent className="py-12 text-center text-muted-foreground">
                  <TrendingUp className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>No active trades</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Trade History Tab */}
          <TabsContent value="history" className="space-y-4">
            <h3 className="text-lg font-semibold">Trade History</h3>
            {tradeHistory && tradeHistory.length > 0 ? (
              <div className="space-y-4">
                {tradeHistory.map((trade) => {
                  const profitLoss = parseFloat(trade.profitLossPercent || "0");
                  const isProfit = profitLoss >= 0;
                  
                  return (
                    <Card key={trade.id}>
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-3 mb-2">
                              <h4 className="font-bold">{trade.tokenSymbol}</h4>
                              <Badge variant="outline">{trade.chainId}</Badge>
                              <Badge variant={trade.status === "open" ? "default" : "secondary"}>
                                {trade.status}
                              </Badge>
                              {trade.exitReason && (
                                <Badge variant="outline">{trade.exitReason.replace("_", " ")}</Badge>
                              )}
                            </div>
                            <div className="grid grid-cols-2 md:grid-cols-5 gap-4 text-sm">
                              <div>
                                <span className="text-muted-foreground">Entry: </span>
                                <span className="font-semibold">${parseFloat(trade.entryPrice).toFixed(6)}</span>
                              </div>
                              {trade.exitPrice && (
                                <div>
                                  <span className="text-muted-foreground">Exit: </span>
                                  <span className="font-semibold">${parseFloat(trade.exitPrice).toFixed(6)}</span>
                                </div>
                              )}
                              {trade.profitLossPercent && (
                                <div>
                                  <span className="text-muted-foreground">P/L: </span>
                                  <span className={`font-semibold ${isProfit ? "text-accent" : "text-destructive"}`}>
                                    {isProfit ? "+" : ""}{profitLoss.toFixed(2)}%
                                  </span>
                                </div>
                              )}
                              {trade.profitLossUsd && (
                                <div>
                                  <span className="text-muted-foreground">USD: </span>
                                  <span className={`font-semibold ${parseFloat(trade.profitLossUsd) >= 0 ? "text-accent" : "text-destructive"}`}>
                                    ${trade.profitLossUsd}
                                  </span>
                                </div>
                              )}
                              <div>
                                <span className="text-muted-foreground">Time: </span>
                                <span className="font-semibold">
                                  {new Date(trade.entryTime).toLocaleString()}
                                </span>
                              </div>
                            </div>
                          </div>
                          {isProfit ? (
                            <TrendingUp className="h-6 w-6 text-accent" />
                          ) : (
                            <TrendingDown className="h-6 w-6 text-destructive" />
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            ) : (
              <Card>
                <CardContent className="py-12 text-center text-muted-foreground">
                  <Activity className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>No trade history yet</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Alerts Tab */}
          <TabsContent value="alerts" className="space-y-4">
            <h3 className="text-lg font-semibold">Alerts & Signals</h3>
            {alerts && alerts.length > 0 ? (
              <div className="space-y-4">
                {alerts.map((alert) => (
                  <Card key={alert.id} className={alert.isRead === 0 ? "border-primary/50" : ""}>
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3">
                        <Bell className={`h-5 w-5 mt-0.5 ${alert.isRead === 0 ? "text-primary" : "text-muted-foreground"}`} />
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <Badge variant={
                              alert.alertType === "buy_signal" ? "default" :
                              alert.alertType === "sell_signal" ? "destructive" :
                              "secondary"
                            }>
                              {alert.alertType.replace("_", " ").toUpperCase()}
                            </Badge>
                            <span className="text-sm text-muted-foreground">
                              {new Date(alert.createdAt).toLocaleString()}
                            </span>
                          </div>
                          <p className="text-sm">{alert.message}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="py-12 text-center text-muted-foreground">
                  <Bell className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>No alerts yet</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
