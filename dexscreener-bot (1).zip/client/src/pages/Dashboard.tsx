import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, TrendingUp, TrendingDown, Activity, ExternalLink, Loader2, ArrowLeft } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { Link } from "wouter";

const SUPPORTED_CHAINS = [
  { id: "solana", name: "Solana" },
  { id: "polygon", name: "Polygon" },
  { id: "ethereum", name: "Ethereum" },
  { id: "bsc", name: "BSC" },
  { id: "avalanche", name: "Avalanche" },
  { id: "arbitrum", name: "Arbitrum" },
  { id: "optimism", name: "Optimism" },
  { id: "base", name: "Base" },
];

export default function Dashboard() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedChain, setSelectedChain] = useState("solana");
  const [activeSearch, setActiveSearch] = useState("");

  // Search query
  const { data: searchResults = [], isLoading: isSearching } = trpc.dexscreener.search.useQuery(
    { query: activeSearch },
    { enabled: activeSearch.length > 0 }
  );

  // Trending tokens
  const { data: boostedTokens, isLoading: isLoadingBoosted } = trpc.dexscreener.getTopBoosted.useQuery();

  const handleSearch = () => {
    if (searchQuery.trim()) {
      setActiveSearch(searchQuery.trim());
    }
  };

  const formatNumber = (num: number | undefined) => {
    if (!num) return "N/A";
    if (num >= 1e9) return `$${(num / 1e9).toFixed(2)}B`;
    if (num >= 1e6) return `$${(num / 1e6).toFixed(2)}M`;
    if (num >= 1e3) return `$${(num / 1e3).toFixed(2)}K`;
    return `$${num.toFixed(2)}`;
  };

  const formatPrice = (price: string | undefined) => {
    if (!price) return "N/A";
    const num = parseFloat(price);
    if (num < 0.000001) return `$${num.toExponential(2)}`;
    if (num < 1) return `$${num.toFixed(6)}`;
    return `$${num.toFixed(2)}`;
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link href="/">
                <Button variant="ghost" size="icon">
                  <ArrowLeft className="h-5 w-5" />
                </Button>
              </Link>
              <div className="flex items-center gap-2">
                <Activity className="h-6 w-6 text-primary" />
                <span className="text-lg font-bold">DexScreener Bot Dashboard</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="container py-8">
        {/* Search Section */}
        <Card className="mb-8 border-primary/20 glow-primary">
          <CardHeader>
            <CardTitle>Token Search</CardTitle>
            <CardDescription>Search for tokens across multiple blockchains</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col md:flex-row gap-4">
              <Select value={selectedChain} onValueChange={setSelectedChain}>
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="Select chain" />
                </SelectTrigger>
                <SelectContent>
                  {SUPPORTED_CHAINS.map((chain) => (
                    <SelectItem key={chain.id} value={chain.id}>
                      {chain.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              <div className="flex-1 flex gap-2">
                <Input
                  placeholder="Search by token name, symbol, or address..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                  className="flex-1"
                />
                <Button onClick={handleSearch} disabled={isSearching}>
                  {isSearching ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Search className="h-4 w-4" />
                  )}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <Tabs defaultValue="search" className="space-y-6">
          <TabsList className="grid w-full md:w-96 grid-cols-2">
            <TabsTrigger value="search">Search Results</TabsTrigger>
            <TabsTrigger value="trending">Trending</TabsTrigger>
          </TabsList>

          {/* Search Results Tab */}
          <TabsContent value="search" className="space-y-4">
            {isSearching && (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            )}

            {!isSearching && activeSearch && searchResults && searchResults.length === 0 && (
              <Card>
                <CardContent className="py-12 text-center text-muted-foreground">
                  No results found for "{activeSearch}"
                </CardContent>
              </Card>
            )}

            {!isSearching && activeSearch && searchResults && searchResults.length > 0 && (
              <div className="space-y-4">
                <div className="text-sm text-muted-foreground">
                  Found {searchResults.length} result{searchResults.length !== 1 ? "s" : ""} for "{activeSearch}"
                </div>
                {searchResults.map((pair, index) => (
                  <Card key={index} className="hover:border-primary/50 transition-all">
                    <CardContent className="p-6">
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <h3 className="text-xl font-bold">
                              {pair.baseToken.symbol} / {pair.quoteToken.symbol}
                            </h3>
                            <Badge variant="outline" className="text-xs">
                              {pair.chainId}
                            </Badge>
                            <Badge variant="outline" className="text-xs">
                              {pair.dexId}
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground mb-3">
                            {pair.baseToken.name}
                          </p>
                          
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                            <div>
                              <div className="text-xs text-muted-foreground mb-1">Price USD</div>
                              <div className="font-semibold">{formatPrice(pair.priceUsd)}</div>
                            </div>
                            <div>
                              <div className="text-xs text-muted-foreground mb-1">24h Volume</div>
                              <div className="font-semibold">{formatNumber(pair.volume?.h24)}</div>
                            </div>
                            <div>
                              <div className="text-xs text-muted-foreground mb-1">Liquidity</div>
                              <div className="font-semibold">{formatNumber(pair.liquidity?.usd)}</div>
                            </div>
                            <div>
                              <div className="text-xs text-muted-foreground mb-1">24h Change</div>
                              <div className={`font-semibold flex items-center gap-1 ${
                                pair.priceChange?.h24 > 0 ? "text-accent" : "text-destructive"
                              }`}>
                                {pair.priceChange?.h24 > 0 ? (
                                  <TrendingUp className="h-4 w-4" />
                                ) : (
                                  <TrendingDown className="h-4 w-4" />
                                )}
                                {pair.priceChange?.h24?.toFixed(2)}%
                              </div>
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex flex-col gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => window.open(pair.url, "_blank")}
                          >
                            View on DexScreener
                            <ExternalLink className="ml-2 h-4 w-4" />
                          </Button>
                        </div>
                      </div>

                      {/* Transaction Stats */}
                      <div className="mt-4 pt-4 border-t border-border">
                        <div className="text-xs text-muted-foreground mb-2">24h Transactions</div>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                          <div>
                            <span className="text-muted-foreground">Buys:</span>{" "}
                            <span className="text-accent font-semibold">{pair.txns?.h24?.buys || 0}</span>
                          </div>
                          <div>
                            <span className="text-muted-foreground">Sells:</span>{" "}
                            <span className="text-destructive font-semibold">{pair.txns?.h24?.sells || 0}</span>
                          </div>
                          <div>
                            <span className="text-muted-foreground">FDV:</span>{" "}
                            <span className="font-semibold">{formatNumber(pair.fdv)}</span>
                          </div>
                          <div>
                            <span className="text-muted-foreground">Market Cap:</span>{" "}
                            <span className="font-semibold">{formatNumber(pair.marketCap)}</span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}

            {!activeSearch && (
              <Card>
                <CardContent className="py-12 text-center text-muted-foreground">
                  <Search className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>Enter a search query to find tokens</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Trending Tab */}
          <TabsContent value="trending" className="space-y-4">
            {isLoadingBoosted && (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            )}

            {!isLoadingBoosted && boostedTokens && boostedTokens.length > 0 && (
              <div className="space-y-4">
                <div className="text-sm text-muted-foreground">
                  Top {boostedTokens.length} boosted tokens
                </div>
                {boostedTokens.map((token, index) => (
                  <Card key={index} className="hover:border-primary/50 transition-all">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          {token.icon && (
                            <img
                              src={token.icon}
                              alt="Token icon"
                              className="h-12 w-12 rounded-full"
                            />
                          )}
                          <div>
                            <div className="flex items-center gap-2 mb-1">
                              <h3 className="text-lg font-bold">Token #{index + 1}</h3>
                              <Badge variant="outline" className="text-xs">
                                {token.chainId}
                              </Badge>
                            </div>
                            <p className="text-sm text-muted-foreground">
                              {token.description || "No description available"}
                            </p>
                            <div className="text-xs text-muted-foreground mt-2">
                              Boost Amount: <span className="text-primary font-semibold">{token.amount}</span>
                            </div>
                          </div>
                        </div>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => window.open(token.url, "_blank")}
                        >
                          View
                          <ExternalLink className="ml-2 h-4 w-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}

            {!isLoadingBoosted && (!boostedTokens || boostedTokens.length === 0) && (
              <Card>
                <CardContent className="py-12 text-center text-muted-foreground">
                  <TrendingUp className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>No trending tokens available at the moment</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
