import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Activity, Zap, Shield, TrendingUp, Search, Bell, BarChart3, Globe, ChevronRight } from "lucide-react";
import { Link } from "wouter";

export default function Home() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Activity className="h-8 w-8 text-primary" />
              <span className="text-xl font-bold gradient-text">DexScreener Bot</span>
            </div>
            <div className="flex items-center gap-4">
              <Link href="/dashboard">
                <Button variant="ghost">Dashboard</Button>
              </Link>
              <Link href="/bot">
                <Button variant="ghost">Trading Bot</Button>
              </Link>
              <Button className="glow-primary">Get Started</Button>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 md:py-32">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-background to-accent/10" />
        <div className="absolute inset-0 bg-[url('/hero-bg.webp')] bg-cover bg-center opacity-5" />
        
        <div className="container relative">
          <div className="mx-auto max-w-4xl text-center">
            <Badge className="mb-6 bg-primary/10 text-primary border-primary/20" variant="outline">
              <Zap className="mr-1 h-3 w-3" />
              Real-Time Crypto Intelligence
            </Badge>
            
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6 leading-tight">
              Your AI-Powered
              <br />
              <span className="gradient-text">DeFi Trading Assistant</span>
            </h1>
            
            <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              Monitor tokens across multiple blockchains in real-time. Get instant alerts, deep market analysis, 
              and trading insights powered by DexScreener's comprehensive DEX data.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/dashboard">
                <Button size="lg" className="glow-primary text-lg px-8">
                  Launch Dashboard
                  <ChevronRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
              <Button size="lg" variant="outline" className="text-lg px-8">
                View Demo
              </Button>
            </div>

            <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-6 max-w-3xl mx-auto">
              {[
                { label: "Chains Supported", value: "15+" },
                { label: "DEXes Tracked", value: "100+" },
                { label: "Real-Time Updates", value: "24/7" },
                { label: "API Rate Limit", value: "300/min" }
              ].map((stat) => (
                <div key={stat.label} className="text-center">
                  <div className="text-2xl md:text-3xl font-bold text-primary">{stat.value}</div>
                  <div className="text-sm text-muted-foreground mt-1">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-card/30">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-bold mb-4">
              Powerful Features for <span className="gradient-text">Smart Trading</span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Everything you need to stay ahead in the fast-paced world of decentralized finance
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                icon: Search,
                title: "Multi-Chain Token Search",
                description: "Search and track tokens across Solana, Polygon, Ethereum, BSC, and 10+ other blockchains instantly."
              },
              {
                icon: Activity,
                title: "Real-Time Price Monitoring",
                description: "Get live price updates, volume data, and liquidity metrics directly from DexScreener's API."
              },
              {
                icon: Bell,
                title: "Smart Alert System",
                description: "Set custom price alerts and volume thresholds. Never miss important market movements."
              },
              {
                icon: BarChart3,
                title: "Advanced Analytics",
                description: "Deep dive into trading patterns, liquidity pools, and market trends with comprehensive charts."
              },
              {
                icon: TrendingUp,
                title: "Trending Tokens",
                description: "Discover trending and boosted tokens before they explode. Stay ahead of the market."
              },
              {
                icon: Shield,
                title: "Secure & Reliable",
                description: "Built with enterprise-grade security. Your data and trading strategies stay private."
              }
            ].map((feature, index) => (
              <Card key={index} className="border-border/50 bg-card hover:border-primary/50 transition-all duration-300 hover:glow-primary">
                <CardHeader>
                  <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                    <feature.icon className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle className="text-xl">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base">{feature.description}</CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-20">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-bold mb-4">
              How It <span className="gradient-text">Works</span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Get started in minutes with our simple three-step process
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {[
              {
                step: "01",
                title: "Connect & Configure",
                description: "Launch the dashboard and select your preferred blockchains. No API keys required - we handle the DexScreener integration."
              },
              {
                step: "02",
                title: "Search & Monitor",
                description: "Search for any token by name, symbol, or contract address. Add tokens to your watchlist for continuous monitoring."
              },
              {
                step: "03",
                title: "Analyze & Trade",
                description: "Get real-time insights, set alerts, and make informed trading decisions based on comprehensive market data."
              }
            ].map((step, index) => (
              <div key={index} className="relative">
                <div className="text-6xl font-bold text-primary/10 mb-4">{step.step}</div>
                <h3 className="text-2xl font-bold mb-3">{step.title}</h3>
                <p className="text-muted-foreground">{step.description}</p>
                {index < 2 && (
                  <ChevronRight className="hidden md:block absolute -right-4 top-12 h-8 w-8 text-primary/30" />
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Supported Chains Section */}
      <section className="py-20 bg-card/30">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-bold mb-4">
              <span className="gradient-text">Multi-Chain</span> Support
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Monitor tokens across all major blockchain networks
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-6 max-w-5xl mx-auto">
            {[
              "Solana", "Polygon", "Ethereum", "BSC", "Avalanche",
              "Arbitrum", "Optimism", "Fantom", "Cronos", "Base"
            ].map((chain) => (
              <Card key={chain} className="border-border/50 bg-card hover:border-primary/50 transition-all duration-300">
                <CardContent className="p-6 text-center">
                  <Globe className="h-8 w-8 text-primary mx-auto mb-3" />
                  <div className="font-semibold">{chain}</div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="container">
          <Card className="border-primary/20 bg-gradient-to-br from-primary/10 to-accent/10 glow-primary">
            <CardContent className="p-12 text-center">
              <h2 className="text-3xl md:text-5xl font-bold mb-4">
                Ready to Start Trading Smarter?
              </h2>
              <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
                Join traders who are already using our DexScreener bot to gain a competitive edge in the crypto markets.
              </p>
              <Link href="/dashboard">
                <Button size="lg" className="text-lg px-8">
                  Launch Dashboard Now
                  <ChevronRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-12 bg-card/50">
        <div className="container">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="flex items-center gap-2">
              <Activity className="h-6 w-6 text-primary" />
              <span className="font-bold">DexScreener Bot</span>
            </div>
            <div className="text-sm text-muted-foreground">
              © 2025 DexScreener Bot. Powered by DexScreener API.
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
