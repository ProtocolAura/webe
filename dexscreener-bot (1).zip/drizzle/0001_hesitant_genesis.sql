CREATE TABLE `alerts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`botConfigId` int NOT NULL,
	`alertType` enum('buy_signal','sell_signal','trade_closed') NOT NULL,
	`tokenSymbol` varchar(32) NOT NULL,
	`chainId` varchar(32) NOT NULL,
	`message` text NOT NULL,
	`priceChange` varchar(32),
	`currentPrice` varchar(64),
	`isRead` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `alerts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `botConfigs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`isActive` int NOT NULL DEFAULT 0,
	`virtualCapital` int NOT NULL DEFAULT 1000,
	`positionSize` int NOT NULL DEFAULT 10,
	`checkInterval` int NOT NULL DEFAULT 300,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `botConfigs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `monitoredTokens` (
	`id` int AUTO_INCREMENT NOT NULL,
	`botConfigId` int NOT NULL,
	`chainId` varchar(32) NOT NULL,
	`tokenAddress` varchar(128) NOT NULL,
	`tokenSymbol` varchar(32),
	`tokenName` text,
	`pairAddress` varchar(128),
	`minLiquidity` int NOT NULL DEFAULT 10000,
	`isActive` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `monitoredTokens_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `trades` (
	`id` int AUTO_INCREMENT NOT NULL,
	`botConfigId` int NOT NULL,
	`monitoredTokenId` int NOT NULL,
	`chainId` varchar(32) NOT NULL,
	`tokenSymbol` varchar(32) NOT NULL,
	`pairAddress` varchar(128),
	`entryPrice` varchar(64) NOT NULL,
	`entryTime` timestamp NOT NULL,
	`entryVolume5m` int,
	`entryPriceChange5m` varchar(32),
	`exitPrice` varchar(64),
	`exitTime` timestamp,
	`exitReason` enum('take_profit','stop_loss','time_limit','manual'),
	`profitLossPercent` varchar(32),
	`profitLossUsd` varchar(32),
	`positionSizeUsd` int NOT NULL,
	`status` enum('open','closed') NOT NULL DEFAULT 'open',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `trades_id` PRIMARY KEY(`id`)
);
