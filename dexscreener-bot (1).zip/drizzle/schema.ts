import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Bot configuration table - stores user's bot settings and monitored tokens
 */
export const botConfigs = mysqlTable("botConfigs", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  isActive: int("isActive").default(0).notNull(), // 0 = stopped, 1 = running
  virtualCapital: int("virtualCapital").default(1000).notNull(), // in USD
  positionSize: int("positionSize").default(10).notNull(), // percentage of capital per trade
  checkInterval: int("checkInterval").default(300).notNull(), // seconds (5 minutes)
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type BotConfig = typeof botConfigs.$inferSelect;
export type InsertBotConfig = typeof botConfigs.$inferInsert;

/**
 * Monitored tokens table - tokens the bot is watching
 */
export const monitoredTokens = mysqlTable("monitoredTokens", {
  id: int("id").autoincrement().primaryKey(),
  botConfigId: int("botConfigId").notNull(),
  chainId: varchar("chainId", { length: 32 }).notNull(),
  tokenAddress: varchar("tokenAddress", { length: 128 }).notNull(),
  tokenSymbol: varchar("tokenSymbol", { length: 32 }),
  tokenName: text("tokenName"),
  pairAddress: varchar("pairAddress", { length: 128 }),
  minLiquidity: int("minLiquidity").default(10000).notNull(), // minimum liquidity in USD
  isActive: int("isActive").default(1).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type MonitoredToken = typeof monitoredTokens.$inferSelect;
export type InsertMonitoredToken = typeof monitoredTokens.$inferInsert;

/**
 * Trade history table - records all virtual trades
 */
export const trades = mysqlTable("trades", {
  id: int("id").autoincrement().primaryKey(),
  botConfigId: int("botConfigId").notNull(),
  monitoredTokenId: int("monitoredTokenId").notNull(),
  chainId: varchar("chainId", { length: 32 }).notNull(),
  tokenSymbol: varchar("tokenSymbol", { length: 32 }).notNull(),
  pairAddress: varchar("pairAddress", { length: 128 }),
  
  // Entry data
  entryPrice: varchar("entryPrice", { length: 64 }).notNull(),
  entryTime: timestamp("entryTime").notNull(),
  entryVolume5m: int("entryVolume5m"), // volume at entry
  entryPriceChange5m: varchar("entryPriceChange5m", { length: 32 }), // price change that triggered entry
  
  // Exit data
  exitPrice: varchar("exitPrice", { length: 64 }),
  exitTime: timestamp("exitTime"),
  exitReason: mysqlEnum("exitReason", ["take_profit", "stop_loss", "time_limit", "manual"]),
  
  // Trade results
  profitLossPercent: varchar("profitLossPercent", { length: 32 }), // percentage gain/loss
  profitLossUsd: varchar("profitLossUsd", { length: 32 }), // USD gain/loss
  positionSizeUsd: int("positionSizeUsd").notNull(), // size of position in USD
  
  status: mysqlEnum("status", ["open", "closed"]).default("open").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Trade = typeof trades.$inferSelect;
export type InsertTrade = typeof trades.$inferInsert;

/**
 * Alerts table - stores buy/sell signals for user notification
 */
export const alerts = mysqlTable("alerts", {
  id: int("id").autoincrement().primaryKey(),
  botConfigId: int("botConfigId").notNull(),
  alertType: mysqlEnum("alertType", ["buy_signal", "sell_signal", "trade_closed"]).notNull(),
  tokenSymbol: varchar("tokenSymbol", { length: 32 }).notNull(),
  chainId: varchar("chainId", { length: 32 }).notNull(),
  message: text("message").notNull(),
  priceChange: varchar("priceChange", { length: 32 }),
  currentPrice: varchar("currentPrice", { length: 64 }),
  isRead: int("isRead").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Alert = typeof alerts.$inferSelect;
export type InsertAlert = typeof alerts.$inferInsert;