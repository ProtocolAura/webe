/**
 * Database helper functions for trading bot
 */

import { getDb } from "./db";
import { botConfigs, monitoredTokens, trades, alerts } from "../drizzle/schema";
import { eq, and, desc } from "drizzle-orm";

/**
 * Get or create bot configuration for a user
 */
export async function getOrCreateBotConfig(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const existing = await db.select().from(botConfigs).where(eq(botConfigs.userId, userId)).limit(1);
  
  if (existing && existing.length > 0) {
    return existing[0];
  }

  // Create default config
  const result = await db.insert(botConfigs).values({
    userId,
    isActive: 0,
    virtualCapital: 1000,
    positionSize: 10,
    checkInterval: 300,
  });

  const newConfig = await db.select().from(botConfigs).where(eq(botConfigs.id, Number(result[0].insertId))).limit(1);
  return newConfig[0];
}

/**
 * Get monitored tokens for a bot
 */
export async function getMonitoredTokens(botConfigId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(monitoredTokens)
    .where(eq(monitoredTokens.botConfigId, botConfigId));
}

/**
 * Add monitored token
 */
export async function addMonitoredToken(data: {
  botConfigId: number;
  chainId: string;
  tokenAddress: string;
  tokenSymbol: string;
  tokenName?: string;
  pairAddress?: string;
  minLiquidity?: number;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Check if token already exists
  const existing = await db.select().from(monitoredTokens)
    .where(and(
      eq(monitoredTokens.botConfigId, data.botConfigId),
      eq(monitoredTokens.tokenAddress, data.tokenAddress),
      eq(monitoredTokens.chainId, data.chainId)
    ))
    .limit(1);

  if (existing && existing.length > 0) {
    return existing[0];
  }

  const result = await db.insert(monitoredTokens).values(data);
  const newToken = await db.select().from(monitoredTokens)
    .where(eq(monitoredTokens.id, Number(result[0].insertId)))
    .limit(1);
  
  return newToken[0];
}

/**
 * Remove monitored token
 */
export async function removeMonitoredToken(tokenId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.delete(monitoredTokens).where(eq(monitoredTokens.id, tokenId));
}

/**
 * Get trade history
 */
export async function getTradeHistory(botConfigId: number, limit: number = 50) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(trades)
    .where(eq(trades.botConfigId, botConfigId))
    .orderBy(desc(trades.createdAt))
    .limit(limit);
}

/**
 * Get active trades
 */
export async function getActiveTrades(botConfigId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(trades)
    .where(and(
      eq(trades.botConfigId, botConfigId),
      eq(trades.status, "open")
    ))
    .orderBy(desc(trades.entryTime));
}

/**
 * Get alerts
 */
export async function getAlerts(botConfigId: number, unreadOnly: boolean = false) {
  const db = await getDb();
  if (!db) return [];

  if (unreadOnly) {
    return await db.select().from(alerts)
      .where(and(
        eq(alerts.botConfigId, botConfigId),
        eq(alerts.isRead, 0)
      ))
      .orderBy(desc(alerts.createdAt))
      .limit(50);
  }

  return await db.select().from(alerts)
    .where(eq(alerts.botConfigId, botConfigId))
    .orderBy(desc(alerts.createdAt))
    .limit(50);
}

/**
 * Mark alert as read
 */
export async function markAlertAsRead(alertId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.update(alerts)
    .set({ isRead: 1 })
    .where(eq(alerts.id, alertId));
}

/**
 * Mark all alerts as read
 */
export async function markAllAlertsAsRead(botConfigId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.update(alerts)
    .set({ isRead: 1 })
    .where(eq(alerts.botConfigId, botConfigId));
}

/**
 * Get bot statistics
 */
export async function getBotStats(botConfigId: number) {
  const db = await getDb();
  if (!db) return null;

  const allTrades = await db.select().from(trades)
    .where(eq(trades.botConfigId, botConfigId));

  const closedTrades = allTrades.filter(t => t.status === "closed");
  const openTrades = allTrades.filter(t => t.status === "open");

  let totalProfitLoss = 0;
  let winningTrades = 0;
  let losingTrades = 0;

  for (const trade of closedTrades) {
    const pl = parseFloat(trade.profitLossUsd || "0");
    totalProfitLoss += pl;
    if (pl > 0) winningTrades++;
    else if (pl < 0) losingTrades++;
  }

  const winRate = closedTrades.length > 0 ? (winningTrades / closedTrades.length) * 100 : 0;

  return {
    totalTrades: allTrades.length,
    closedTrades: closedTrades.length,
    openTrades: openTrades.length,
    winningTrades,
    losingTrades,
    winRate: winRate.toFixed(1),
    totalProfitLoss: totalProfitLoss.toFixed(2),
  };
}

/**
 * Update bot configuration
 */
export async function updateBotConfig(botConfigId: number, updates: {
  virtualCapital?: number;
  positionSize?: number;
  checkInterval?: number;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.update(botConfigs)
    .set(updates)
    .where(eq(botConfigs.id, botConfigId));
}
