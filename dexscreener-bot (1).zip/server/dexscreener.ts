/**
 * DexScreener API Integration
 * Base URL: https://api.dexscreener.com
 * 
 * Rate Limits:
 * - Token/Pair endpoints: 300 requests per minute
 * - Profile/Metadata endpoints: 60 requests per minute
 */

const DEXSCREENER_BASE_URL = "https://api.dexscreener.com";

export interface TokenPair {
  chainId: string;
  dexId: string;
  url: string;
  pairAddress: string;
  baseToken: {
    address: string;
    name: string;
    symbol: string;
  };
  quoteToken: {
    address: string;
    name: string;
    symbol: string;
  };
  priceNative: string;
  priceUsd?: string;
  txns: {
    m5: { buys: number; sells: number };
    h1: { buys: number; sells: number };
    h6: { buys: number; sells: number };
    h24: { buys: number; sells: number };
  };
  volume: {
    h24: number;
    h6: number;
    h1: number;
    m5: number;
  };
  priceChange: {
    m5: number;
    h1: number;
    h6: number;
    h24: number;
  };
  liquidity?: {
    usd?: number;
    base: number;
    quote: number;
  };
  fdv?: number;
  marketCap?: number;
  pairCreatedAt?: number;
}

export interface SearchResult {
  schemaVersion: string;
  pairs: TokenPair[];
}

export interface TokenProfile {
  url: string;
  chainId: string;
  tokenAddress: string;
  icon?: string;
  header?: string;
  description?: string;
  links?: {
    type: string;
    label: string;
    url: string;
  }[];
}

export interface BoostedToken {
  url: string;
  chainId: string;
  tokenAddress: string;
  icon?: string;
  description?: string;
  amount: number;
}

/**
 * Search for token pairs matching a query
 */
export async function searchPairs(query: string): Promise<TokenPair[]> {
  try {
    if (!query || query.trim().length === 0) {
      return [];
    }

    const trimmedQuery = query.trim();
    const response = await fetch(
      `${DEXSCREENER_BASE_URL}/latest/dex/search?q=${encodeURIComponent(trimmedQuery)}`,
      { method: 'GET', headers: { 'Accept': 'application/json' } }
    );
    
    if (!response.ok) {
      console.warn(`DexScreener API returned ${response.status} for query: ${trimmedQuery}`);
      return [];
    }
    
    const data: SearchResult = await response.json();
    return data.pairs || [];
  } catch (error) {
    console.error("Error searching pairs:", error);
    return [];
  }
}

/**
 * Get pairs by chain and pair address
 */
export async function getPairsByChainAndAddress(
  chainId: string,
  pairAddress: string
): Promise<TokenPair | null> {
  try {
    const response = await fetch(
      `${DEXSCREENER_BASE_URL}/latest/dex/pairs/${chainId}/${pairAddress}`
    );
    
    if (!response.ok) {
      throw new Error(`DexScreener API error: ${response.status}`);
    }
    
    const data: SearchResult = await response.json();
    return data.pairs?.[0] || null;
  } catch (error) {
    console.error("Error fetching pair:", error);
    throw error;
  }
}

/**
 * Get token pairs by chain and token address
 */
export async function getTokenPairs(
  chainId: string,
  tokenAddress: string
): Promise<TokenPair[]> {
  try {
    const response = await fetch(
      `${DEXSCREENER_BASE_URL}/token-pairs/v1/${chainId}/${tokenAddress}`
    );
    
    if (!response.ok) {
      throw new Error(`DexScreener API error: ${response.status}`);
    }
    
    const data = await response.json();
    return data || [];
  } catch (error) {
    console.error("Error fetching token pairs:", error);
    throw error;
  }
}

/**
 * Get multiple tokens by chain and addresses (up to 30 addresses)
 */
export async function getTokens(
  chainId: string,
  tokenAddresses: string[]
): Promise<TokenPair[]> {
  try {
    if (tokenAddresses.length > 30) {
      throw new Error("Maximum 30 token addresses allowed");
    }
    
    const addressesParam = tokenAddresses.join(",");
    const response = await fetch(
      `${DEXSCREENER_BASE_URL}/tokens/v1/${chainId}/${addressesParam}`
    );
    
    if (!response.ok) {
      throw new Error(`DexScreener API error: ${response.status}`);
    }
    
    const data = await response.json();
    return data || [];
  } catch (error) {
    console.error("Error fetching tokens:", error);
    throw error;
  }
}

/**
 * Get the latest token profiles (rate-limit: 60 requests per minute)
 */
export async function getLatestTokenProfiles(): Promise<TokenProfile[]> {
  try {
    const response = await fetch(
      `${DEXSCREENER_BASE_URL}/token-profiles/latest/v1`
    );
    
    if (!response.ok) {
      throw new Error(`DexScreener API error: ${response.status}`);
    }
    
    const data = await response.json();
    return data || [];
  } catch (error) {
    console.error("Error fetching token profiles:", error);
    throw error;
  }
}

/**
 * Get the latest boosted tokens (rate-limit: 60 requests per minute)
 */
export async function getLatestBoostedTokens(): Promise<BoostedToken[]> {
  try {
    const response = await fetch(
      `${DEXSCREENER_BASE_URL}/token-boosts/latest/v1`
    );
    
    if (!response.ok) {
      throw new Error(`DexScreener API error: ${response.status}`);
    }
    
    const data = await response.json();
    return data || [];
  } catch (error) {
    console.error("Error fetching boosted tokens:", error);
    throw error;
  }
}

/**
 * Get tokens with most active boosts (rate-limit: 60 requests per minute)
 */
export async function getTopBoostedTokens(): Promise<BoostedToken[]> {
  try {
    const response = await fetch(
      `${DEXSCREENER_BASE_URL}/token-boosts/top/v1`
    );
    
    if (!response.ok) {
      throw new Error(`DexScreener API error: ${response.status}`);
    }
    
    const data = await response.json();
    return data || [];
  } catch (error) {
    console.error("Error fetching top boosted tokens:", error);
    throw error;
  }
}
