import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  dexscreener: router({
    search: publicProcedure
      .input(z.object({ query: z.string().min(1) }))
      .query(async ({ input }) => {
        const { searchPairs } = await import('./dexscreener');
        return await searchPairs(input.query);
      }),
    
    getPair: publicProcedure
      .input(z.object({
        chainId: z.string(),
        pairAddress: z.string()
      }))
      .query(async ({ input }) => {
        const { getPairsByChainAndAddress } = await import('./dexscreener');
        return await getPairsByChainAndAddress(input.chainId, input.pairAddress);
      }),
    
    getTokenPairs: publicProcedure
      .input(z.object({
        chainId: z.string(),
        tokenAddress: z.string()
      }))
      .query(async ({ input }) => {
        const { getTokenPairs } = await import('./dexscreener');
        return await getTokenPairs(input.chainId, input.tokenAddress);
      }),
    
    getTokens: publicProcedure
      .input(z.object({
        chainId: z.string(),
        tokenAddresses: z.array(z.string()).max(30)
      }))
      .query(async ({ input }) => {
        const { getTokens } = await import('./dexscreener');
        return await getTokens(input.chainId, input.tokenAddresses);
      }),
    
    getLatestProfiles: publicProcedure
      .query(async () => {
        const { getLatestTokenProfiles } = await import('./dexscreener');
        return await getLatestTokenProfiles();
      }),
    
    getLatestBoosted: publicProcedure
      .query(async () => {
        const { getLatestBoostedTokens } = await import('./dexscreener');
        return await getLatestBoostedTokens();
      }),
    
    getTopBoosted: publicProcedure
      .query(async () => {
        const { getTopBoostedTokens } = await import('./dexscreener');
        return await getTopBoostedTokens();
      }),
  }),

  bot: router({
    // Get or create bot config
    getConfig: protectedProcedure
      .query(async ({ ctx }) => {
        const { getOrCreateBotConfig } = await import('./botDb');
        return await getOrCreateBotConfig(ctx.user.id);
      }),
    
    // Update bot config
    updateConfig: protectedProcedure
      .input(z.object({
        virtualCapital: z.number().optional(),
        positionSize: z.number().min(1).max(100).optional(),
        checkInterval: z.number().min(60).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const { getOrCreateBotConfig, updateBotConfig } = await import('./botDb');
        const config = await getOrCreateBotConfig(ctx.user.id);
        await updateBotConfig(config.id, input);
        return { success: true };
      }),
    
    // Start bot
    start: protectedProcedure
      .mutation(async ({ ctx }) => {
        const { getOrCreateBotConfig } = await import('./botDb');
        const { startBot } = await import('./tradingBot');
        const config = await getOrCreateBotConfig(ctx.user.id);
        await startBot(config.id);
        return { success: true };
      }),
    
    // Stop bot
    stop: protectedProcedure
      .mutation(async ({ ctx }) => {
        const { getOrCreateBotConfig } = await import('./botDb');
        const { stopBot } = await import('./tradingBot');
        const config = await getOrCreateBotConfig(ctx.user.id);
        await stopBot(config.id);
        return { success: true };
      }),
    
    // Get bot status
    getStatus: protectedProcedure
      .query(async ({ ctx }) => {
        const { getOrCreateBotConfig } = await import('./botDb');
        const { getBotStatus } = await import('./tradingBot');
        const config = await getOrCreateBotConfig(ctx.user.id);
        return getBotStatus(config.id);
      }),
    
    // Get monitored tokens
    getTokens: protectedProcedure
      .query(async ({ ctx }) => {
        const { getOrCreateBotConfig, getMonitoredTokens } = await import('./botDb');
        const config = await getOrCreateBotConfig(ctx.user.id);
        return await getMonitoredTokens(config.id);
      }),
    
    // Add monitored token
    addToken: protectedProcedure
      .input(z.object({
        chainId: z.string(),
        tokenAddress: z.string(),
        tokenSymbol: z.string(),
        tokenName: z.string().optional(),
        pairAddress: z.string().optional(),
        minLiquidity: z.number().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const { getOrCreateBotConfig, addMonitoredToken } = await import('./botDb');
        const config = await getOrCreateBotConfig(ctx.user.id);
        return await addMonitoredToken({
          botConfigId: config.id,
          ...input,
        });
      }),
    
    // Remove monitored token
    removeToken: protectedProcedure
      .input(z.object({ tokenId: z.number() }))
      .mutation(async ({ input }) => {
        const { removeMonitoredToken } = await import('./botDb');
        await removeMonitoredToken(input.tokenId);
        return { success: true };
      }),
    
    // Get trade history
    getTradeHistory: protectedProcedure
      .input(z.object({ limit: z.number().optional() }))
      .query(async ({ ctx, input }) => {
        const { getOrCreateBotConfig, getTradeHistory } = await import('./botDb');
        const config = await getOrCreateBotConfig(ctx.user.id);
        return await getTradeHistory(config.id, input.limit);
      }),
    
    // Get active trades
    getActiveTrades: protectedProcedure
      .query(async ({ ctx }) => {
        const { getOrCreateBotConfig, getActiveTrades } = await import('./botDb');
        const config = await getOrCreateBotConfig(ctx.user.id);
        return await getActiveTrades(config.id);
      }),
    
    // Get alerts
    getAlerts: protectedProcedure
      .input(z.object({ unreadOnly: z.boolean().optional() }))
      .query(async ({ ctx, input }) => {
        const { getOrCreateBotConfig, getAlerts } = await import('./botDb');
        const config = await getOrCreateBotConfig(ctx.user.id);
        return await getAlerts(config.id, input.unreadOnly);
      }),
    
    // Mark alert as read
    markAlertRead: protectedProcedure
      .input(z.object({ alertId: z.number() }))
      .mutation(async ({ input }) => {
        const { markAlertAsRead } = await import('./botDb');
        await markAlertAsRead(input.alertId);
        return { success: true };
      }),
    
    // Get bot statistics
    getStats: protectedProcedure
      .query(async ({ ctx }) => {
        const { getOrCreateBotConfig, getBotStats } = await import('./botDb');
        const config = await getOrCreateBotConfig(ctx.user.id);
        return await getBotStats(config.id);
      }),
  }),
});

export type AppRouter = typeof appRouter;
