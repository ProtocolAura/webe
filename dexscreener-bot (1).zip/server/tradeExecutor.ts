/**
 * Trade Executor Service
 * Handles automatic trade execution based on bot signals
 */

import { getDb } from './db';
import { trades, alerts } from '../drizzle/schema';
import { eq, and } from 'drizzle-orm';

export interface TradeSignal {
  tokenAddress: string;
  chainId: string;
  entryPrice: number;
  amount: string;
  timestamp: Date;
}

export interface TradeExecution {
  tradeId: number;
  txHash: string;
  executedAt: Date;
  status: 'pending' | 'confirmed' | 'failed';
}

/**
 * Create a trade record when a buy signal is generated
 */
export async function createTradeFromSignal(
  botConfigId: number,
  monitoredTokenId: number,
  signal: TradeSignal
): Promise<number | null> {
  const db = await getDb();
  if (!db) return null;

  try {
    await db.insert(trades).values({
      botConfigId,
      monitoredTokenId,
      chainId: signal.chainId,
      tokenSymbol: '',
      entryPrice: signal.entryPrice.toString(),
      entryTime: signal.timestamp,
      positionSizeUsd: parseInt(signal.amount),
      status: 'open',
      createdAt: new Date(),
      updatedAt: new Date(),
    });

    // Return the created trade ID (would be returned from the insert)
    return 1;
  } catch (error) {
    console.error('Failed to create trade record:', error);
    return null;
  }
}

/**
 * Update trade status after execution
 */
export async function updateTradeExecution(
  tradeId: number,
  txHash: string
): Promise<boolean> {
  const db = await getDb();
  if (!db) return false;

  try {
    await db.update(trades)
      .set({
        updatedAt: new Date(),
      })
      .where(eq(trades.id, tradeId));

    return true;
  } catch (error) {
    console.error('Failed to update trade execution:', error);
    return false;
  }
}

/**
 * Close a trade with exit conditions
 */
export async function closeTrade(
  tradeId: number,
  exitPrice: number,
  exitReason: 'take_profit' | 'stop_loss' | 'time_limit'
): Promise<boolean> {
  const db = await getDb();
  if (!db) return false;

  try {
    const trade = await db.select().from(trades).where(eq(trades.id, tradeId)).limit(1);
    
    if (trade.length === 0) return false;

    const t = trade[0];
    const entryPriceNum = parseFloat(t.entryPrice);
    const pnlPercent = ((exitPrice - entryPriceNum) / entryPriceNum) * 100;
    const pnlUsd = (exitPrice - entryPriceNum) * (t.positionSizeUsd || 0);

    await db.update(trades)
      .set({
        exitPrice: exitPrice.toString(),
        exitTime: new Date(),
        exitReason,
        profitLossPercent: pnlPercent.toString(),
        profitLossUsd: pnlUsd.toString(),
        status: 'closed',
        updatedAt: new Date(),
      })
      .where(eq(trades.id, tradeId));

    return true;
  } catch (error) {
    console.error('Failed to close trade:', error);
    return false;
  }
}

/**
 * Get active trades for a user
 */
export async function getActiveTrades(botConfigId: number) {
  const db = await getDb();
  if (!db) return [];

  try {
    return await db.select()
      .from(trades)
      .where(and(
        eq(trades.botConfigId, botConfigId),
        eq(trades.status, 'open')
      ));
  } catch (error) {
    console.error('Failed to get active trades:', error);
    return [];
  }
}

/**
 * Get trade history for a user
 */
export async function getTradeHistory(botConfigId: number, limit: number = 50) {
  const db = await getDb();
  if (!db) return [];

  try {
    return await db.select()
      .from(trades)
      .where(eq(trades.botConfigId, botConfigId))
      .orderBy(trades.exitTime)
      .limit(limit);
  } catch (error) {
    console.error('Failed to get trade history:', error);
    return [];
  }
}

/**
 * Calculate trading statistics
 */
export async function calculateTradingStats(botConfigId: number) {
  const db = await getDb();
  if (!db) return null;

  try {
    const tradeList = await db.select()
      .from(trades)
      .where(eq(trades.botConfigId, botConfigId));

    if (tradeList.length === 0) {
      return {
        totalTrades: 0,
        winningTrades: 0,
        losingTrades: 0,
        winRate: 0,
        totalPnL: 0,
        averagePnL: 0,
      };
    }

    const closedTrades = tradeList.filter(t => t.status === 'closed');
    const winningTrades = closedTrades.filter(t => parseFloat(t.profitLossUsd || '0') > 0);
    const losingTrades = closedTrades.filter(t => parseFloat(t.profitLossUsd || '0') < 0);
    const totalPnL = closedTrades.reduce((sum, t) => sum + parseFloat(t.profitLossUsd || '0'), 0);

    return {
      totalTrades: tradeList.length,
      activeTrades: tradeList.filter(t => t.status === 'open').length,
      closedTrades: closedTrades.length,
      winningTrades: winningTrades.length,
      losingTrades: losingTrades.length,
      winRate: closedTrades.length > 0 ? (winningTrades.length / closedTrades.length) * 100 : 0,
      totalPnL,
      averagePnL: closedTrades.length > 0 ? totalPnL / closedTrades.length : 0,
    };
  } catch (error) {
    console.error('Failed to calculate trading stats:', error);
    return null;
  }
}
