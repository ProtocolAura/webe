/**
 * Trading Bot Engine - Scalp Momentum + Micro Pump Detector
 * 
 * Strategy:
 * - Detect micro pumps (3-8% gains)
 * - Entry: +2.5% price change in 5min + 3x volume spike + liquidity > $10k
 * - Exit: +5% take profit, -3% stop loss, or 60min time limit
 */

import { getDb } from "./db";
import { botConfigs, monitoredTokens, trades, alerts, InsertTrade, InsertAlert } from "../drizzle/schema";
import { eq, and } from "drizzle-orm";
import { searchPairs, getTokenPairs, TokenPair } from "./dexscreener";

interface BotState {
  isRunning: boolean;
  intervalId?: NodeJS.Timeout;
  activeTrades: Map<number, ActiveTrade[]>;
}

interface ActiveTrade {
  tradeId: number;
  monitoredTokenId: number;
  tokenSymbol: string;
  chainId: string;
  tokenAddress: string;
  pairAddress: string;
  entryPrice: number;
  entryTime: Date;
  positionSizeUsd: number;
  takeProfitPercent: number;
  stopLossPercent: number;
}

interface TradingSignal {
  monitoredToken: any;
  pair: TokenPair;
  priceChange5m: number;
  volumeRatio: number;
  liquidityUsd: number;
  currentPrice: number;
}

const botStates = new Map<number, BotState>();

/**
 * Start the trading bot for a specific bot configuration
 */
export async function startBot(botConfigId: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Check if bot is already running
  if (botStates.has(botConfigId) && botStates.get(botConfigId)?.isRunning) {
    console.log(`[Bot ${botConfigId}] Already running`);
    return;
  }

  // Get bot configuration
  const config = await db.select().from(botConfigs).where(eq(botConfigs.id, botConfigId)).limit(1);
  if (!config || config.length === 0) {
    throw new Error(`Bot configuration ${botConfigId} not found`);
  }

  // Update bot status to active
  await db.update(botConfigs)
    .set({ isActive: 1 })
    .where(eq(botConfigs.id, botConfigId));

  // Initialize bot state
  const botState: BotState = {
    isRunning: true,
    activeTrades: new Map(),
  };

  // Load existing open trades
  const openTrades = await db.select().from(trades)
    .where(and(
      eq(trades.botConfigId, botConfigId),
      eq(trades.status, "open")
    ));

  for (const trade of openTrades) {
    const monitoredToken = await db.select().from(monitoredTokens)
      .where(eq(monitoredTokens.id, trade.monitoredTokenId))
      .limit(1);
    
    const tokenAddress = monitoredToken && monitoredToken.length > 0 ? monitoredToken[0].tokenAddress : "";
    
    const activeTrade: ActiveTrade = {
      tradeId: trade.id,
      monitoredTokenId: trade.monitoredTokenId,
      tokenSymbol: trade.tokenSymbol,
      chainId: trade.chainId,
      tokenAddress,
      pairAddress: trade.pairAddress || "",
      entryPrice: parseFloat(trade.entryPrice),
      entryTime: trade.entryTime,
      positionSizeUsd: trade.positionSizeUsd,
      takeProfitPercent: 5.0,
      stopLossPercent: -3.0,
    };
    
    if (!botState.activeTrades.has(trade.monitoredTokenId)) {
      botState.activeTrades.set(trade.monitoredTokenId, []);
    }
    botState.activeTrades.get(trade.monitoredTokenId)!.push(activeTrade);
  }

  botStates.set(botConfigId, botState);

  // Start monitoring loop
  const checkInterval = config[0].checkInterval * 1000; // convert to milliseconds
  botState.intervalId = setInterval(() => {
    monitorTokens(botConfigId).catch(err => {
      console.error(`[Bot ${botConfigId}] Error in monitoring loop:`, err);
    });
  }, checkInterval);

  console.log(`[Bot ${botConfigId}] Started with ${checkInterval}ms interval`);
  
  // Run first check immediately
  await monitorTokens(botConfigId);
}

/**
 * Stop the trading bot
 */
export async function stopBot(botConfigId: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const botState = botStates.get(botConfigId);
  if (!botState || !botState.isRunning) {
    console.log(`[Bot ${botConfigId}] Not running`);
    return;
  }

  // Clear interval
  if (botState.intervalId) {
    clearInterval(botState.intervalId);
  }

  // Update bot status
  await db.update(botConfigs)
    .set({ isActive: 0 })
    .where(eq(botConfigs.id, botConfigId));

  botState.isRunning = false;
  botStates.delete(botConfigId);

  console.log(`[Bot ${botConfigId}] Stopped`);
}

/**
 * Main monitoring function - checks all tokens for signals
 */
async function monitorTokens(botConfigId: number): Promise<void> {
  const db = await getDb();
  if (!db) return;

  const botState = botStates.get(botConfigId);
  if (!botState || !botState.isRunning) return;

  // Get bot configuration
  const config = await db.select().from(botConfigs).where(eq(botConfigs.id, botConfigId)).limit(1);
  if (!config || config.length === 0) return;

  // Get monitored tokens
  const tokens = await db.select().from(monitoredTokens)
    .where(and(
      eq(monitoredTokens.botConfigId, botConfigId),
      eq(monitoredTokens.isActive, 1)
    ));

  console.log(`[Bot ${botConfigId}] Monitoring ${tokens.length} tokens`);

  for (const token of tokens) {
    try {
      // Check for exit conditions on active trades
      if (botState.activeTrades.has(token.id)) {
        await checkExitConditions(botConfigId, token.id, botState.activeTrades.get(token.id)!);
      }

      // Check for entry signals (only if no active trade for this token)
      if (!botState.activeTrades.has(token.id)) {
        const signal = await detectEntrySignal(token);
        if (signal) {
          await executeEntry(botConfigId, signal, config[0], botState);
        }
      }
    } catch (error) {
      console.error(`[Bot ${botConfigId}] Error monitoring token ${token.tokenSymbol}:`, error);
    }
  }
}

/**
 * Detect entry signal based on strategy criteria
 */
async function detectEntrySignal(token: any): Promise<TradingSignal | null> {
  try {
    // Get token pairs from DexScreener
    const pairs = await getTokenPairs(token.chainId, token.tokenAddress);
    if (!pairs || pairs.length === 0) return null;

    // Use the pair with highest liquidity
    const pair = pairs.sort((a, b) => (b.liquidity?.usd || 0) - (a.liquidity?.usd || 0))[0];

    // Check liquidity filter
    const liquidityUsd = pair.liquidity?.usd || 0;
    if (liquidityUsd < token.minLiquidity) {
      return null;
    }

    // Check momentum (price change in last 5 minutes)
    const priceChange5m = pair.priceChange?.m5 || 0;
    if (priceChange5m < 2.5) {
      return null;
    }

    // Check volume spike (5min volume vs 1hour average)
    const volume5m = pair.volume?.m5 || 0;
    const volume1h = pair.volume?.h1 || 0;
    const avgVolume5m = volume1h / 12; // average 5min volume over 1 hour
    const volumeRatio = avgVolume5m > 0 ? volume5m / avgVolume5m : 0;

    if (volumeRatio < 3.0) {
      return null;
    }

    const currentPrice = parseFloat(pair.priceUsd || "0");
    if (currentPrice === 0) return null;

    console.log(`[Signal] ${token.tokenSymbol}: +${priceChange5m.toFixed(2)}%, Vol: ${volumeRatio.toFixed(1)}x, Liq: $${liquidityUsd.toFixed(0)}`);

    return {
      monitoredToken: token,
      pair,
      priceChange5m,
      volumeRatio,
      liquidityUsd,
      currentPrice,
    };
  } catch (error) {
    console.error(`Error detecting signal for ${token.tokenSymbol}:`, error);
    return null;
  }
}

/**
 * Execute entry (open virtual trade)
 */
async function executeEntry(
  botConfigId: number,
  signal: TradingSignal,
  config: any,
  botState: BotState
): Promise<void> {
  const db = await getDb();
  if (!db) return;

  const positionSizeUsd = Math.floor((config.virtualCapital * config.positionSize) / 100);

  const newTrade: InsertTrade = {
    botConfigId,
    monitoredTokenId: signal.monitoredToken.id,
    chainId: signal.monitoredToken.chainId,
    tokenSymbol: signal.monitoredToken.tokenSymbol,
    pairAddress: signal.pair.pairAddress,
    entryPrice: signal.currentPrice.toString(),
    entryTime: new Date(),
    entryVolume5m: Math.floor(signal.pair.volume?.m5 || 0),
    entryPriceChange5m: signal.priceChange5m.toFixed(2),
    positionSizeUsd,
    status: "open",
  };

  const result = await db.insert(trades).values(newTrade);
  const tradeId = Number(result[0].insertId);

  // Add to active trades
  botState.activeTrades.set(signal.monitoredToken.id, {
    tradeId,
    monitoredTokenId: signal.monitoredToken.id,
    tokenSymbol: signal.monitoredToken.tokenSymbol,
    chainId: signal.monitoredToken.chainId,
    tokenAddress: signal.monitoredToken.tokenAddress,
    pairAddress: signal.pair.pairAddress,
    entryPrice: signal.currentPrice,
    entryTime: new Date(),
    positionSizeUsd,
    takeProfitPercent: 5.0,
    stopLossPercent: -3.0,
  });

  // Create alert
  const alert: InsertAlert = {
    botConfigId,
    alertType: "buy_signal",
    tokenSymbol: signal.monitoredToken.tokenSymbol,
    chainId: signal.monitoredToken.chainId,
    message: `🚀 BUY SIGNAL: ${signal.monitoredToken.tokenSymbol} - Price: $${signal.currentPrice.toFixed(6)}, Change: +${signal.priceChange5m.toFixed(2)}%, Volume: ${signal.volumeRatio.toFixed(1)}x`,
    priceChange: signal.priceChange5m.toFixed(2),
    currentPrice: signal.currentPrice.toString(),
    isRead: 0,
  };

  await db.insert(alerts).values(alert);

  console.log(`[Bot ${botConfigId}] 🟢 ENTRY: ${signal.monitoredToken.tokenSymbol} @ $${signal.currentPrice.toFixed(6)}`);
}

/**
 * Check exit conditions for active trade
 */
async function checkExitConditions(
  botConfigId: number,
  monitoredTokenId: number,
  activeTrade: ActiveTrade
): Promise<void> {
  const db = await getDb();
  if (!db) return;

  try {
    // Get current price using token address (not pair address)
    const pairs = await getTokenPairs(activeTrade.chainId, activeTrade.tokenAddress);
    if (!pairs || pairs.length === 0) {
      console.warn(`[Bot ${botConfigId}] No pairs found for ${activeTrade.tokenSymbol}`);
      return;
    }

    const pair = pairs[0];
    const currentPrice = parseFloat(pair.priceUsd || "0");
    if (currentPrice === 0) {
      console.warn(`[Bot ${botConfigId}] Invalid price for ${activeTrade.tokenSymbol}`);
      return;
    }

    const priceChangePercent = ((currentPrice - activeTrade.entryPrice) / activeTrade.entryPrice) * 100;
    const timeElapsed = Date.now() - activeTrade.entryTime.getTime();
    const minutesElapsed = timeElapsed / (1000 * 60);

    let shouldExit = false;
    let exitReason: "take_profit" | "stop_loss" | "time_limit" | "manual" = "manual";

    // Check take profit (+5%)
    if (priceChangePercent >= activeTrade.takeProfitPercent) {
      shouldExit = true;
      exitReason = "take_profit";
      console.log(`[Bot ${botConfigId}] ${activeTrade.tokenSymbol}: Take Profit triggered (+${priceChangePercent.toFixed(2)}%)`);
    }
    // Check stop loss (-3%)
    else if (priceChangePercent <= activeTrade.stopLossPercent) {
      shouldExit = true;
      exitReason = "stop_loss";
      console.log(`[Bot ${botConfigId}] ${activeTrade.tokenSymbol}: Stop Loss triggered (${priceChangePercent.toFixed(2)}%)`);
    }
    // Check time limit (60 minutes)
    else if (minutesElapsed >= 60) {
      shouldExit = true;
      exitReason = "time_limit";
      console.log(`[Bot ${botConfigId}] ${activeTrade.tokenSymbol}: Time Limit triggered (${minutesElapsed.toFixed(1)} minutes)`);
    }

    if (shouldExit) {
      await executeExit(botConfigId, activeTrade, currentPrice, priceChangePercent, exitReason);
    }
  } catch (error) {
    console.error(`Error checking exit for ${activeTrade.tokenSymbol}:`, error);
  }
}

/**
 * Execute exit (close virtual trade)
 */
async function executeExit(
  botConfigId: number,
  activeTrade: ActiveTrade,
  exitPrice: number,
  profitLossPercent: number,
  exitReason: "take_profit" | "stop_loss" | "time_limit" | "manual"
): Promise<void> {
  const db = await getDb();
  if (!db) return;

  const botState = botStates.get(botConfigId);
  if (!botState) return;

  const profitLossUsd = (activeTrade.positionSizeUsd * profitLossPercent) / 100;

  // Update trade record
  await db.update(trades)
    .set({
      exitPrice: exitPrice.toString(),
      exitTime: new Date(),
      exitReason,
      profitLossPercent: profitLossPercent.toFixed(2),
      profitLossUsd: profitLossUsd.toFixed(2),
      status: "closed",
    })
    .where(eq(trades.id, activeTrade.tradeId));

  // Remove from active trades
  botState.activeTrades.delete(activeTrade.monitoredTokenId);

  // Create alert
  const emoji = profitLossPercent > 0 ? "✅" : "❌";
  const alert: InsertAlert = {
    botConfigId,
    alertType: "trade_closed",
    tokenSymbol: activeTrade.tokenSymbol,
    chainId: activeTrade.chainId,
    message: `${emoji} TRADE CLOSED: ${activeTrade.tokenSymbol} - ${exitReason.toUpperCase()} - P/L: ${profitLossPercent > 0 ? "+" : ""}${profitLossPercent.toFixed(2)}% ($${profitLossUsd.toFixed(2)})`,
    priceChange: profitLossPercent.toFixed(2),
    currentPrice: exitPrice.toString(),
    isRead: 0,
  };

  await db.insert(alerts).values(alert);

  console.log(`[Bot ${botConfigId}] 🔴 EXIT: ${activeTrade.tokenSymbol} @ $${exitPrice.toFixed(6)} - ${exitReason} - P/L: ${profitLossPercent.toFixed(2)}%`);
}

/**
 * Get bot status
 */
export function getBotStatus(botConfigId: number): { isRunning: boolean; activeTradesCount: number } {
  const botState = botStates.get(botConfigId);
  return {
    isRunning: botState?.isRunning || false,
    activeTradesCount: botState?.activeTrades.size || 0,
  };
}
